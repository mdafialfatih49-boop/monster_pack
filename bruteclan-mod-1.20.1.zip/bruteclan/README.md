# Brute Clan (Ogre, Cyclops, Troll) - Fabric 1.20.1

Build jar: push ke GitHub, tab Actions > build > unduh artifact "bruteclan-jar".
Atau lokal: `gradle build` (Gradle 8.5, Java 17), hasil di build/libs/bruteclan-1.0.0.jar

Perlu Fabric API 0.92.2+1.20.1. Semua aset ada di namespace sendiri: assets/bruteclan (tidak menimpa vanilla).
Tab kreatif: "Brute Clan" berisi 3 spawn egg.
