package com.bruteclan;

import com.bruteclan.entity.*;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.world.Heightmap;

public class BruteClanMod implements ModInitializer {
    public static final String MOD_ID = "bruteclan";

    public static final EntityType<OgreEntity> OGRE = Registry.register(Registries.ENTITY_TYPE,
            new Identifier(MOD_ID, "ogre"),
            EntityType.Builder.create(OgreEntity::new, SpawnGroup.MONSTER).setDimensions(1.6f, 3.0f).maxTrackingRange(10).build("ogre"));
    public static final EntityType<CyclopsEntity> CYCLOPS = Registry.register(Registries.ENTITY_TYPE,
            new Identifier(MOD_ID, "cyclops"),
            EntityType.Builder.create(CyclopsEntity::new, SpawnGroup.MONSTER).setDimensions(1.9f, 3.5f).maxTrackingRange(10).build("cyclops"));
    public static final EntityType<TrollEntity> TROLL = Registry.register(Registries.ENTITY_TYPE,
            new Identifier(MOD_ID, "troll"),
            EntityType.Builder.create(TrollEntity::new, SpawnGroup.MONSTER).setDimensions(1.7f, 3.1f).maxTrackingRange(10).build("troll"));

    public static final Item OGRE_EGG = Registry.register(Registries.ITEM, new Identifier(MOD_ID, "ogre_spawn_egg"),
            new SpawnEggItem(OGRE, 0x4A6B33, 0x5A4636, new Item.Settings()));
    public static final Item CYCLOPS_EGG = Registry.register(Registries.ITEM, new Identifier(MOD_ID, "cyclops_spawn_egg"),
            new SpawnEggItem(CYCLOPS, 0x536A38, 0xC81E14, new Item.Settings()));
    public static final Item TROLL_EGG = Registry.register(Registries.ITEM, new Identifier(MOD_ID, "troll_spawn_egg"),
            new SpawnEggItem(TROLL, 0x3F5A2D, 0x7E9A62, new Item.Settings()));

    public static final ItemGroup GROUP = Registry.register(Registries.ITEM_GROUP, new Identifier(MOD_ID, "main"),
            FabricItemGroup.builder()
                    .icon(() -> new ItemStack(OGRE_EGG))
                    .displayName(Text.translatable("itemGroup.bruteclan.main"))
                    .entries((ctx, entries) -> {
                        entries.add(OGRE_EGG);
                        entries.add(CYCLOPS_EGG);
                        entries.add(TROLL_EGG);
                    }).build());

    @Override
    public void onInitialize() {
        FabricDefaultAttributeRegistry.register(OGRE, BruteEntity.attributes(60, 0.27, 10));
        FabricDefaultAttributeRegistry.register(CYCLOPS, BruteEntity.attributes(90, 0.24, 14));
        FabricDefaultAttributeRegistry.register(TROLL, BruteEntity.attributes(70, 0.30, 9));

        SpawnRestriction.register(OGRE, SpawnRestriction.Location.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        SpawnRestriction.register(CYCLOPS, SpawnRestriction.Location.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        SpawnRestriction.register(TROLL, SpawnRestriction.Location.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);

        // Ogre: dataran & hutan; Cyclops: perbukitan & gunung; Troll: hutan & taiga
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, OGRE, 4, 1, 1);
        BiomeModifications.addSpawn(BiomeSelectors.tag(BiomeTags.IS_HILL).or(BiomeSelectors.tag(BiomeTags.IS_MOUNTAIN)), SpawnGroup.MONSTER, CYCLOPS, 6, 1, 1);
        BiomeModifications.addSpawn(BiomeSelectors.tag(BiomeTags.IS_FOREST).or(BiomeSelectors.tag(BiomeTags.IS_TAIGA)), SpawnGroup.MONSTER, TROLL, 8, 1, 2);
    }
}
