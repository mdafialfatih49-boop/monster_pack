package com.bruteclan.client;

import com.bruteclan.BruteClanMod;
import com.bruteclan.entity.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

public class BruteClanClient implements ClientModInitializer {
    public static final EntityModelLayer OGRE_LAYER = new EntityModelLayer(new Identifier(BruteClanMod.MOD_ID, "ogre"), "main");
    public static final EntityModelLayer CYCLOPS_LAYER = new EntityModelLayer(new Identifier(BruteClanMod.MOD_ID, "cyclops"), "main");
    public static final EntityModelLayer TROLL_LAYER = new EntityModelLayer(new Identifier(BruteClanMod.MOD_ID, "troll"), "main");

    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(OGRE_LAYER, () -> BruteModel.create(BruteModel.Weapon.AXE, false));
        EntityModelLayerRegistry.registerModelLayer(CYCLOPS_LAYER, () -> BruteModel.create(BruteModel.Weapon.CLUB, false));
        EntityModelLayerRegistry.registerModelLayer(TROLL_LAYER, () -> BruteModel.create(BruteModel.Weapon.CLUB, true));

        EntityRendererRegistry.register(BruteClanMod.OGRE, ctx -> new BruteRenderer<OgreEntity>(ctx, OGRE_LAYER, "textures/entity/ogre.png", 1.3f, 1.2f));
        EntityRendererRegistry.register(BruteClanMod.CYCLOPS, ctx -> new BruteRenderer<CyclopsEntity>(ctx, CYCLOPS_LAYER, "textures/entity/cyclops.png", 1.5f, 1.4f));
        EntityRendererRegistry.register(BruteClanMod.TROLL, ctx -> new BruteRenderer<TrollEntity>(ctx, TROLL_LAYER, "textures/entity/troll.png", 1.35f, 1.2f));
    }
}
