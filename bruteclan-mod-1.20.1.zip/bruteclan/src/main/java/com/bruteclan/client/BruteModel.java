package com.bruteclan.client;

import com.bruteclan.entity.BruteEntity;
import net.minecraft.client.model.*;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;

public class BruteModel<T extends BruteEntity> extends EntityModel<T> {
    public enum Weapon { AXE, CLUB }

    private final ModelPart root, head, rightArm, leftArm, rightLeg, leftLeg;

    public BruteModel(ModelPart root) {
        super(RenderLayer::getEntityCutoutNoCull);
        this.root = root;
        this.head = root.getChild("head");
        this.rightArm = root.getChild("right_arm");
        this.leftArm = root.getChild("left_arm");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
    }

    public static TexturedModelData create(Weapon weapon, boolean twigs) {
        ModelData data = new ModelData();
        ModelPartData r = data.getRoot();

        ModelPartData head = r.addChild("head", ModelPartBuilder.create().uv(0, 0).cuboid(-5, -10, -5, 10, 10, 10), ModelTransform.pivot(0, -2, 0));
        head.addChild("hair", ModelPartBuilder.create().uv(40, 0).cuboid(-5, -10, -5, 10, 10, 10, new Dilation(0.6f)), ModelTransform.NONE);
        head.addChild("tusk_r", ModelPartBuilder.create().uv(80, 0).cuboid(-4, -4, -6, 2, 4, 1), ModelTransform.NONE);
        head.addChild("tusk_l", ModelPartBuilder.create().uv(80, 0).cuboid(2, -4, -6, 2, 4, 1), ModelTransform.NONE);
        if (twigs) {
            head.addChild("twig_1", ModelPartBuilder.create().uv(90, 0).cuboid(-3, -14, -2, 1, 5, 1), ModelTransform.rotation(0, 0, -0.3f));
            head.addChild("twig_2", ModelPartBuilder.create().uv(90, 0).cuboid(1, -14, 1, 1, 5, 1), ModelTransform.rotation(0.3f, 0, 0.35f));
            head.addChild("twig_3", ModelPartBuilder.create().uv(90, 0).cuboid(-1, -14, 2, 1, 5, 1), ModelTransform.rotation(-0.35f, 0, 0));
        }

        r.addChild("body", ModelPartBuilder.create().uv(0, 20).cuboid(-8, -14, -5, 16, 14, 10), ModelTransform.pivot(0, 12, 0));

        ModelPartData ra = r.addChild("right_arm", ModelPartBuilder.create().uv(0, 48).cuboid(-3.5f, -2, -3.5f, 7, 22, 7), ModelTransform.pivot(-11.5f, 1, 0));
        r.addChild("left_arm", ModelPartBuilder.create().uv(28, 48).cuboid(-3.5f, -2, -3.5f, 7, 22, 7), ModelTransform.pivot(11.5f, 1, 0));

        if (weapon == Weapon.AXE) {
            ra.addChild("weapon", ModelPartBuilder.create()
                    .uv(60, 40).cuboid(-1, -18, -1, 2, 24, 2)
                    .uv(70, 40).cuboid(-9, -18, -2, 8, 7, 4), ModelTransform.pivot(0, 19, -6));
        } else {
            ra.addChild("weapon", ModelPartBuilder.create()
                    .uv(0, 80).cuboid(-5, -20, -3, 10, 24, 6), ModelTransform.pivot(-1, 19, -7));
        }

        r.addChild("right_leg", ModelPartBuilder.create().uv(60, 20).cuboid(-3, 0, -3, 6, 12, 6), ModelTransform.pivot(-4, 12, 0));
        r.addChild("left_leg", ModelPartBuilder.create().uv(84, 20).cuboid(-3, 0, -3, 6, 12, 6), ModelTransform.pivot(4, 12, 0));
        return TexturedModelData.of(data, 128, 128);
    }

    private static float tri(float v, float m) {
        return (Math.abs(v % m - m * 0.5f) - m * 0.25f) / (m * 0.25f);
    }

    @Override
    public void setAngles(T e, float limbAngle, float limbDistance, float anim, float headYaw, float headPitch) {
        head.yaw = headYaw * 0.017453292f;
        head.pitch = headPitch * 0.017453292f;
        rightLeg.pitch = -1.5f * tri(limbAngle, 13f) * limbDistance;
        leftLeg.pitch = 1.5f * tri(limbAngle, 13f) * limbDistance;
        int atk = e.getAttackTicksLeft();
        if (atk > 0) {
            rightArm.pitch = -2.0f + 1.5f * tri(atk, 10f);
            leftArm.pitch = -2.0f + 1.5f * tri(atk, 10f);
        } else {
            rightArm.pitch = (-0.2f + 1.5f * tri(limbAngle, 13f)) * limbDistance;
            leftArm.pitch = (-0.2f - 1.5f * tri(limbAngle, 13f)) * limbDistance;
        }
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay, float r, float g, float b, float a) {
        root.render(matrices, vertices, light, overlay, r, g, b, a);
    }
}
