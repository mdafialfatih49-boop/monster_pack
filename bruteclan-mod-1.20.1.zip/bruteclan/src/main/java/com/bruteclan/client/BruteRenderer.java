package com.bruteclan.client;

import com.bruteclan.BruteClanMod;
import com.bruteclan.entity.BruteEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class BruteRenderer<T extends BruteEntity> extends MobEntityRenderer<T, BruteModel<T>> {
    private final Identifier texture;
    private final float scale;

    public BruteRenderer(EntityRendererFactory.Context ctx, EntityModelLayer layer, String tex, float scale, float shadow) {
        super(ctx, new BruteModel<>(ctx.getPart(layer)), shadow);
        this.texture = new Identifier(BruteClanMod.MOD_ID, tex);
        this.scale = scale;
    }

    @Override public Identifier getTexture(T entity) { return texture; }

    @Override protected void scale(T entity, MatrixStack matrices, float amount) { matrices.scale(scale, scale, scale); }
}
