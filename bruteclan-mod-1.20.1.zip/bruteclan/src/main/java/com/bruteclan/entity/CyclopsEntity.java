package com.bruteclan.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

public class CyclopsEntity extends BruteEntity {
    public CyclopsEntity(EntityType<? extends CyclopsEntity> type, World world) { super(type, world); }
    
}
