package com.bruteclan.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

public class OgreEntity extends BruteEntity {
    public OgreEntity(EntityType<? extends OgreEntity> type, World world) { super(type, world); }
    
}
