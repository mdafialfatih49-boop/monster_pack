package com.bruteclan.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.world.World;

public class TrollEntity extends BruteEntity {
    public TrollEntity(EntityType<? extends TrollEntity> type, World world) { super(type, world); }
    @Override protected float regen() { return 1.0f; }
}
